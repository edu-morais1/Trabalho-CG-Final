#include "core/Scene.h"
#include "pipeline/Rasterizer.h"

// Função que Python chamará via pybind11 ou ctypes
extern "C" void render_api(int width, int height,
                           /* parâmetros da cena */,
                           uint32_t* out_pixels) {
    Scene scene;
    // preencher camera, cubes, lights a partir dos parâmetros

    Framebuffer fb(width, height);
    fb.clear(0xff000000);

    renderScene(scene, fb, /*usePhong*/ true);

    std::copy(fb.color.begin(), fb.color.end(), out_pixels);
}

